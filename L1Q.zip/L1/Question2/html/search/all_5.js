var searchData=
[
  ['newdeque_8',['newDeque',['../PS-2_8c.html#ab9d6aab03cb660f16977513e240b39d7',1,'PS-2.c']]]
];
