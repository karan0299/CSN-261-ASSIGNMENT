var searchData=
[
  ['search_43',['search',['../PS-1_8c.html#aaad50dfc23d8e85c6373349849b85ae6',1,'PS-1.c']]],
  ['search_5fqueue_44',['search_queue',['../PS-1_8c.html#a0153a7aacbce534b5082e57af31a4e48',1,'PS-1.c']]],
  ['sortbyname_45',['sortByName',['../PS-1_8c.html#a16af310ad608852c74a4b3c1f5c694c9',1,'PS-1.c']]],
  ['sortbyrollnumber_46',['sortByRollNumber',['../PS-1_8c.html#a4a4a143e1a7fa6bf90c3a799f74f9703',1,'PS-1.c']]],
  ['swap_5fint_47',['swap_int',['../PS-1_8c.html#a4c72369c9202f982163ec9fed42d1b03',1,'PS-1.c']]]
];
