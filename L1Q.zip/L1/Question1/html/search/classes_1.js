var searchData=
[
  ['queue_32',['queue',['../structqueue.html',1,'']]]
];
