var searchData=
[
  ['name_12',['name',['../structnode.html#a927074d29c4ed217600018a9c7e8beb6',1,'node']]],
  ['newnode_13',['newNode',['../PS-1_8c.html#a6578e01c6355b6a2425cd0c6c5c6db45',1,'PS-1.c']]],
  ['next_14',['next',['../structnode.html#aa3e8aa83f864292b5a01210f4453fcc0',1,'node']]],
  ['node_15',['node',['../structnode.html',1,'node'],['../PS-1_8c.html#ace29f146c273d2654669dc2c710603e2',1,'node():&#160;PS-1.c']]]
];
