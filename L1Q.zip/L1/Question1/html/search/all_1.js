var searchData=
[
  ['delete_2',['delete',['../PS-1_8c.html#a3bcfd34802ff7b2faca2cf7405801678',1,'PS-1.c']]],
  ['dob_3',['dob',['../structnode.html#a27af97d1a3bf7870c4f7d89670420877',1,'node']]]
];
