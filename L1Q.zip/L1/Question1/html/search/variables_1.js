var searchData=
[
  ['dob_50',['dob',['../structnode.html#a27af97d1a3bf7870c4f7d89670420877',1,'node']]]
];
