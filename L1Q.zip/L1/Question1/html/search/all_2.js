var searchData=
[
  ['first_4',['first',['../PS-1_8c.html#a02b4428208fd0060bb54d5bb726702d4',1,'PS-1.c']]],
  ['front_5',['front',['../structqueue.html#a6c50c7c8bcd9c5962996ed8b1be8771c',1,'queue']]]
];
