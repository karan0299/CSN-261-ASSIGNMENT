var searchData=
[
  ['name_54',['name',['../structnode.html#a927074d29c4ed217600018a9c7e8beb6',1,'node']]],
  ['next_55',['next',['../structnode.html#aa3e8aa83f864292b5a01210f4453fcc0',1,'node']]]
];
