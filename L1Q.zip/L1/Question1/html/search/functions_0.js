var searchData=
[
  ['delete_34',['delete',['../PS-1_8c.html#a3bcfd34802ff7b2faca2cf7405801678',1,'PS-1.c']]]
];
