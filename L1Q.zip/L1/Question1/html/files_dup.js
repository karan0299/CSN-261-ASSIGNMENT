var files_dup =
[
    [ "PS-1.c", "PS-1_8c.html", "PS-1_8c" ]
];