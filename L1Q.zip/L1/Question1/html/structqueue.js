var structqueue =
[
    [ "arr", "structqueue.html#a10c922fe79aea10d78d423ebc8cd5e0e", null ],
    [ "rear", "structqueue.html#a473ab80725514ce07817f87ed1fb136f", null ],
    [ "front", "structqueue.html#a6c50c7c8bcd9c5962996ed8b1be8771c", null ],
    [ "size", "structqueue.html#afb9096840ba43e124b3a58648db557cc", null ]
];