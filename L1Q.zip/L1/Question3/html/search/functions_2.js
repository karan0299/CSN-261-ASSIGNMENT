var searchData=
[
  ['pixelvalue_13',['pixelValue',['../PS-3_8c.html#a62f8f1cce75c2372c35df7a14952d86c',1,'PS-3.c']]],
  ['preserveblue_14',['preserveBlue',['../PS-3_8c.html#a93334a6068ac79fd69b32bc9c1860473',1,'PS-3.c']]],
  ['preservegreen_15',['preserveGreen',['../PS-3_8c.html#a9bc480010c5e3db3b4ba8e4726570b33',1,'PS-3.c']]],
  ['preservered_16',['preserveRed',['../PS-3_8c.html#ada9d71439a3dc34b86e9163bfe6c5c3e',1,'PS-3.c']]]
];
