var structnode =
[
    [ "roll", "structnode.html#a701f7b0bf07919c4b3bf83f4abe34372", null ],
    [ "name", "structnode.html#a927074d29c4ed217600018a9c7e8beb6", null ],
    [ "dob", "structnode.html#a27af97d1a3bf7870c4f7d89670420877", null ],
    [ "addr", "structnode.html#af9bb16570210fb3b9ccdd3b984bfea71", null ],
    [ "phno", "structnode.html#ac26d226e1daa751841ece82b19e7cc4a", null ],
    [ "prev", "structnode.html#a7ee3d227c728ce18a86e43ebc301046e", null ],
    [ "next", "structnode.html#aa3e8aa83f864292b5a01210f4453fcc0", null ]
];