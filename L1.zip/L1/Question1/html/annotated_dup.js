var annotated_dup =
[
    [ "node", "structnode.html", "structnode" ],
    [ "queue", "structqueue.html", "structqueue" ]
];