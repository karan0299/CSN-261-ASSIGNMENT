var searchData=
[
  ['phno_56',['phno',['../structnode.html#ac26d226e1daa751841ece82b19e7cc4a',1,'node']]],
  ['prev_57',['prev',['../structnode.html#a7ee3d227c728ce18a86e43ebc301046e',1,'node']]]
];
