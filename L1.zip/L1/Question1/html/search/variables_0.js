var searchData=
[
  ['addr_48',['addr',['../structnode.html#af9bb16570210fb3b9ccdd3b984bfea71',1,'node']]],
  ['arr_49',['arr',['../structqueue.html#a10c922fe79aea10d78d423ebc8cd5e0e',1,'queue']]]
];
