var searchData=
[
  ['phno_16',['phno',['../structnode.html#ac26d226e1daa751841ece82b19e7cc4a',1,'node']]],
  ['pop_17',['pop',['../PS-1_8c.html#a929eaf0d729b866014d273eb894bf2b1',1,'PS-1.c']]],
  ['prev_18',['prev',['../structnode.html#a7ee3d227c728ce18a86e43ebc301046e',1,'node']]],
  ['printlist_19',['printList',['../PS-1_8c.html#a2f736094bbaa598f70c3e241bad4a1cc',1,'PS-1.c']]],
  ['ps_2d1_2ec_20',['PS-1.c',['../PS-1_8c.html',1,'']]],
  ['push_21',['push',['../PS-1_8c.html#a8ccd6305bf0fb0b5a7b8c4f9a306607d',1,'PS-1.c']]]
];
