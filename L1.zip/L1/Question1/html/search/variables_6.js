var searchData=
[
  ['rear_58',['rear',['../structqueue.html#a473ab80725514ce07817f87ed1fb136f',1,'queue']]],
  ['roll_59',['roll',['../structnode.html#a701f7b0bf07919c4b3bf83f4abe34372',1,'node']]]
];
