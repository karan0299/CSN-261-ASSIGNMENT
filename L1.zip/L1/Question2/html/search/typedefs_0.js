var searchData=
[
  ['deque_30',['deque',['../PS-2_8c.html#a69c50f916f04c544e6dc5175e1dbc07b',1,'PS-2.c']]]
];
