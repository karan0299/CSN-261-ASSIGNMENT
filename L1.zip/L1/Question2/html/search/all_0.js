var searchData=
[
  ['deleteback_0',['deleteBack',['../PS-2_8c.html#a4ed43c9d4332f89d4fafec6a61d1be60',1,'PS-2.c']]],
  ['deletefront_1',['deleteFront',['../PS-2_8c.html#ade1e6228863ef67ae110cb60f9ee2829',1,'PS-2.c']]],
  ['deque_2',['deque',['../structdeque.html',1,'deque'],['../PS-2_8c.html#a69c50f916f04c544e6dc5175e1dbc07b',1,'deque():&#160;PS-2.c']]]
];
