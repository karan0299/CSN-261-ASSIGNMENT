var searchData=
[
  ['ptr_27',['ptr',['../structdeque.html#abebde1190732c64ac84fb7a00add2cac',1,'deque']]]
];
