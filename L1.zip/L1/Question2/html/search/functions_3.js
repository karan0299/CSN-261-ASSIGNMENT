var searchData=
[
  ['insertback_21',['insertBack',['../PS-2_8c.html#a3d37c0b2851c9ff831e02b48f3e9c4ff',1,'PS-2.c']]],
  ['insertfront_22',['insertFront',['../PS-2_8c.html#a078d20c9837014e77d80f2b7be470b77',1,'PS-2.c']]]
];
