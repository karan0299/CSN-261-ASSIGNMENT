var indexSectionsWithContent =
{
  0: "degimnprs",
  1: "d",
  2: "p",
  3: "degimnps",
  4: "prs",
  5: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs"
};

