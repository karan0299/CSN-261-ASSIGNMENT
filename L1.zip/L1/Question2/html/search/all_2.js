var searchData=
[
  ['get_4',['get',['../PS-2_8c.html#adddced7a8c51c51ca8698992b070010d',1,'PS-2.c']]]
];
