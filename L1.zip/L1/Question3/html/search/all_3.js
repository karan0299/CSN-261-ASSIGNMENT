var searchData=
[
  ['removeblue_7',['removeBlue',['../PS-3_8c.html#a0720a33738bbbd4d44b974421a4aef4f',1,'PS-3.c']]],
  ['removegreen_8',['removeGreen',['../PS-3_8c.html#a83078eeb22a8d7686498a59daf8e0808',1,'PS-3.c']]],
  ['removered_9',['removeRed',['../PS-3_8c.html#a4b58a96629f706959887d0b170d746af',1,'PS-3.c']]]
];
