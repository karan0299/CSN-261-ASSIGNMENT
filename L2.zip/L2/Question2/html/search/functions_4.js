var searchData=
[
  ['new_5fnode_28',['new_node',['../MAT_8c.html#a7d7f5abbfdb16ce4050ba1235e361a09',1,'MAT.c']]]
];
