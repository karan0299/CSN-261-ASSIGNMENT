var searchData=
[
  ['bit_5fvalue_31',['bit_value',['../structNode.html#a921de3da587516349b0527862e8b63f4',1,'Node']]],
  ['btmright_32',['btmright',['../structNode.html#aaa9062a8f1e7cdb47c6eccefdfdedf5f',1,'Node']]]
];
