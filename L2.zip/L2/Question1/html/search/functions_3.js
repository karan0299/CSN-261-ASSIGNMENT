var searchData=
[
  ['gcd_15',['gcd',['../inverseTranspose_8c.html#a0683e038a239223d81abaac88bd63e21',1,'gcd(int n, int a):&#160;inverseTranspose.c'],['../transpose_8c.html#a0683e038a239223d81abaac88bd63e21',1,'gcd(int n, int a):&#160;transpose.c']]]
];
