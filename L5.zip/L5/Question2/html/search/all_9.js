var searchData=
[
  ['source',['source',['../structedge.html#a123c11d0720940e8a2556269ad340118',1,'edge']]]
];
