var searchData=
[
  ['kruskal',['kruskal',['../Q2_8cpp.html#ab44e8afa059bb16a7305d8b3f1272c68',1,'Q2.cpp']]]
];
