var searchData=
[
  ['union',['Union',['../Q2_8cpp.html#a1ef911bfe88ce1d49d8c565ff0b4232c',1,'Q2.cpp']]]
];
