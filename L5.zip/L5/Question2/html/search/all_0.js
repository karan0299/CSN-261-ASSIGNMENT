var searchData=
[
  ['compare',['compare',['../Q2_8cpp.html#ab8784b04f5587180fef11726c653d4ff',1,'Q2.cpp']]]
];
