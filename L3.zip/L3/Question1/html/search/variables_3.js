var searchData=
[
  ['root',['root',['../classBST.html#a649f05efb8f63efa407101a485319f2d',1,'BST']]]
];
