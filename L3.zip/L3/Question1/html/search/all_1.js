var searchData=
[
  ['color',['color',['../structnode.html#ad3d475f22776899938bbca39b65f2414',1,'node']]]
];
