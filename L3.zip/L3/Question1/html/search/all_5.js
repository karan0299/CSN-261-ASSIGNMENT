var searchData=
[
  ['left',['left',['../structnode.html#a7cbff55ff448f557223f79299056e9b1',1,'node']]]
];
