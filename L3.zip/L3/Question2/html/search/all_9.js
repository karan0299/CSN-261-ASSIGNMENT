var searchData=
[
  ['right',['right',['../structnode.html#a875f75abfe22103500535b179828e4e3',1,'node']]]
];
