var searchData=
[
  ['initialize',['initialize',['../Q2_8cpp.html#a06bc318f325422fef630e0045690be11',1,'Q2.cpp']]],
  ['initialize2d',['initialize2d',['../Q2_8cpp.html#ae308c89b6d12cef4f4b0bb08d3e0c7da',1,'Q2.cpp']]],
  ['insert',['insert',['../Q2_8cpp.html#a076abba2f9ccb3e9c9f3970c9832daca',1,'Q2.cpp']]]
];
