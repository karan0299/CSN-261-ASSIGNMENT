var searchData=
[
  ['ans',['ans',['../Q2_8cpp.html#acf40520af3f90e4252425ef2d5bdb95a',1,'Q2.cpp']]]
];
