var searchData=
[
  ['countanswer',['countAnswer',['../Q2_8cpp.html#a0763a5732f5ebbbc5519cef505411ca5',1,'Q2.cpp']]]
];
