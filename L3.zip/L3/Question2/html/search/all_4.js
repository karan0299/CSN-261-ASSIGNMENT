var searchData=
[
  ['get',['get',['../Q2_8cpp.html#ae1a929e63699a7bf56be923deef4b26b',1,'Q2.cpp']]]
];
