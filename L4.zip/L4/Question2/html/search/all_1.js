var searchData=
[
  ['nqueen',['nQueen',['../Q2_8cpp.html#abff523f489c86a9def4520909c92c585',1,'Q2.cpp']]]
];
