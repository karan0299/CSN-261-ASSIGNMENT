var searchData=
[
  ['high',['high',['../Q3_8cpp.html#aae03a5bfee63ef73c818b660e31146a9',1,'Q3.cpp']]]
];
