var searchData=
[
  ['low',['low',['../Q3_8cpp.html#a582ad3e71a0125d122e77eb54d2277b4',1,'Q3.cpp']]]
];
